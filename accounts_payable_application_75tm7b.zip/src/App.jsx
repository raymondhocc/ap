import React from 'react'
import './App.css'

export default function App() {
  return (
    <div className="app">
      <header className="top-menu">
        <div className="logo">Accounts Payable</div>
        <nav>
          <a href="#">Dashboard</a>
          <a href="#">Reports</a>
          <a href="#">Settings</a>
          <a href="#">Profile</a>
        </nav>
      </header>

      <div className="main-container">
        <aside className="left-sidebar">
          <nav>
            <div className="nav-item">Dashboard</div>
            <div className="nav-item">Vendors</div>
            <div className="nav-item">Invoices</div>
            <div className="nav-item">Payments</div>
            <div className="nav-item">Reports</div>
          </nav>
        </aside>

        <main className="content">
          <h1>Welcome to Accounts Payable</h1>
          <p>Select an option from the sidebar to get started.</p>
        </main>

        <aside className="right-sidebar">
          <div className="widget">
            <h3>Recent Activity</h3>
            <ul>
              <li>Invoice #123 paid</li>
              <li>New vendor added</li>
              <li>Payment processed</li>
            </ul>
          </div>
          <div className="widget">
            <h3>Quick Actions</h3>
            <button>New Invoice</button>
            <button>Add Vendor</button>
            <button>Make Payment</button>
          </div>
        </aside>
      </div>

      <footer className="bottom-menu">
        <div className="footer-stats">
          <div>Total Payables: $45,000</div>
          <div>Overdue: $5,000</div>
          <div>Paid this month: $15,000</div>
        </div>
        <div className="footer-links">
          <a href="#">Help</a>
          <a href="#">Support</a>
          <a href="#">Terms</a>
          <a href="#">Privacy</a>
        </div>
      </footer>
    </div>
  )
}
