import { useState } from 'react'
import { Table, Button, Modal, TextInput, NumberInput, Select, Group } from '@mantine/core'
import { DateInput } from '@mantine/dates'

export default function Invoices() {
  const [opened, setOpened] = useState(false)
  const [invoices, setInvoices] = useState([])

  const addInvoice = (values) => {
    setInvoices([...invoices, { id: Date.now(), ...values }])
    setOpened(false)
  }

  return (
    <>
      <Button onClick={() => setOpened(true)} mb="md">Add Invoice</Button>
      
      <Table>
        <thead>
          <tr>
            <th>Invoice #</th>
            <th>Vendor</th>
            <th>Amount</th>
            <th>Due Date</th>
            <th>Status</th>
          </tr>
        </thead>
        <tbody>
          {invoices.map((invoice) => (
            <tr key={invoice.id}>
              <td>{invoice.number}</td>
              <td>{invoice.vendor}</td>
              <td>${invoice.amount}</td>
              <td>{invoice.dueDate}</td>
              <td>{invoice.status}</td>
            </tr>
          ))}
        </tbody>
      </Table>

      <Modal
        opened={opened}
        onClose={() => setOpened(false)}
        title="Add New Invoice"
      >
        <form onSubmit={(e) => {
          e.preventDefault()
          const formData = new FormData(e.target)
          addInvoice(Object.fromEntries(formData))
        }}>
          <TextInput
            label="Invoice Number"
            name="number"
            required
            mb="sm"
          />
          <Select
            label="Vendor"
            name="vendor"
            data={[]}
            required
            mb="sm"
          />
          <NumberInput
            label="Amount"
            name="amount"
            required
            mb="sm"
            precision={2}
            min={0}
          />
          <DateInput
            label="Due Date"
            name="dueDate"
            required
            mb="sm"
          />
          <Group position="right">
            <Button type="submit">Save</Button>
          </Group>
        </form>
      </Modal>
    </>
  )
}
