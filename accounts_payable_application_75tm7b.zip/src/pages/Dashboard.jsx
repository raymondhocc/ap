import { Grid, Card, Text, Group } from '@mantine/core'

export default function Dashboard() {
  return (
    <Grid>
      <Grid.Col span={4}>
        <Card shadow="sm">
          <Group position="apart">
            <Text weight={500}>Total Payables</Text>
            <Text size="xl">$0.00</Text>
          </Group>
        </Card>
      </Grid.Col>
      <Grid.Col span={4}>
        <Card shadow="sm">
          <Group position="apart">
            <Text weight={500}>Overdue</Text>
            <Text size="xl">$0.00</Text>
          </Group>
        </Card>
      </Grid.Col>
      <Grid.Col span={4}>
        <Card shadow="sm">
          <Group position="apart">
            <Text weight={500}>Paid This Month</Text>
            <Text size="xl">$0.00</Text>
          </Group>
        </Card>
      </Grid.Col>
    </Grid>
  )
}
