import { useState } from 'react'
import { Table, Button, Modal, Select, NumberInput, Group } from '@mantine/core'
import { DateInput } from '@mantine/dates'

export default function Payments() {
  const [opened, setOpened] = useState(false)
  const [payments, setPayments] = useState([])

  const addPayment = (values) => {
    setPayments([...payments, { id: Date.now(), ...values }])
    setOpened(false)
  }

  return (
    <>
      <Button onClick={() => setOpened(true)} mb="md">Record Payment</Button>
      
      <Table>
        <thead>
          <tr>
            <th>Date</th>
            <th>Invoice #</th>
            <th>Vendor</th>
            <th>Amount</th>
            <th>Method</th>
          </tr>
        </thead>
        <tbody>
          {payments.map((payment) => (
            <tr key={payment.id}>
              <td>{payment.date}</td>
              <td>{payment.invoice}</td>
              <td>{payment.vendor}</td>
              <td>${payment.amount}</td>
              <td>{payment.method}</td>
            </tr>
          ))}
        </tbody>
      </Table>

      <Modal
        opened={opened}
        onClose={() => setOpened(false)}
        title="Record Payment"
      >
        <form onSubmit={(e) => {
          e.preventDefault()
          const formData = new FormData(e.target)
          addPayment(Object.fromEntries(formData))
        }}>
          <Select
            label="Invoice"
            name="invoice"
            data={[]}
            required
            mb="sm"
          />
          <NumberInput
            label="Amount"
            name="amount"
            required
            mb="sm"
            precision={2}
            min={0}
          />
          <Select
            label="Payment Method"
            name="method"
            data={['Bank Transfer', 'Check', 'Credit Card']}
            required
            mb="sm"
          />
          <DateInput
            label="Payment Date"
            name="date"
            required
            mb="sm"
          />
          <Group position="right">
            <Button type="submit">Save</Button>
          </Group>
        </form>
      </Modal>
    </>
  )
}
