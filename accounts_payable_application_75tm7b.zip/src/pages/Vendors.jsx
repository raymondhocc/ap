import { useState } from 'react'
import { Table, Button, Modal, TextInput, Group } from '@mantine/core'

export default function Vendors() {
  const [opened, setOpened] = useState(false)
  const [vendors, setVendors] = useState([])

  const addVendor = (values) => {
    setVendors([...vendors, { id: Date.now(), ...values }])
    setOpened(false)
  }

  return (
    <>
      <Button onClick={() => setOpened(true)} mb="md">Add Vendor</Button>
      
      <Table>
        <thead>
          <tr>
            <th>Name</th>
            <th>Email</th>
            <th>Phone</th>
          </tr>
        </thead>
        <tbody>
          {vendors.map((vendor) => (
            <tr key={vendor.id}>
              <td>{vendor.name}</td>
              <td>{vendor.email}</td>
              <td>{vendor.phone}</td>
            </tr>
          ))}
        </tbody>
      </Table>

      <Modal
        opened={opened}
        onClose={() => setOpened(false)}
        title="Add New Vendor"
      >
        <form onSubmit={(e) => {
          e.preventDefault()
          const formData = new FormData(e.target)
          addVendor(Object.fromEntries(formData))
        }}>
          <TextInput
            label="Name"
            name="name"
            required
            mb="sm"
          />
          <TextInput
            label="Email"
            name="email"
            type="email"
            mb="sm"
          />
          <TextInput
            label="Phone"
            name="phone"
            mb="sm"
          />
          <Group position="right">
            <Button type="submit">Save</Button>
          </Group>
        </form>
      </Modal>
    </>
  )
}
