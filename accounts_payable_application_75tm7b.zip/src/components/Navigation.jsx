import { Navbar, UnstyledButton, Group, Text } from '@mantine/core'
import { useNavigate } from 'react-router-dom'

export default function Navigation() {
  const navigate = useNavigate()

  const items = [
    { label: 'Dashboard', path: '/' },
    { label: 'Vendors', path: '/vendors' },
    { label: 'Invoices', path: '/invoices' },
    { label: 'Payments', path: '/payments' }
  ]

  return (
    <Navbar width={{ base: 300 }} p="xs">
      {items.map((item) => (
        <UnstyledButton
          key={item.path}
          onClick={() => navigate(item.path)}
          sx={(theme) => ({
            display: 'block',
            width: '100%',
            padding: theme.spacing.xs,
            borderRadius: theme.radius.sm,
            '&:hover': {
              backgroundColor: theme.colors.gray[0]
            }
          })}
        >
          <Group>
            <Text size="sm">{item.label}</Text>
          </Group>
        </UnstyledButton>
      ))}
    </Navbar>
  )
}
